library(devtools)
library(twitteR)
library(httr)
library(sentiment)
library(DT)
library(devtools)
library(wordcloud)

if (!require("pacman")) install.packages("pacman")
pacman::p_load(devtools, installr)



api_key <- "t4f2zQp9044P92l5J6PCz9wW2"
api_secret <- "cEKCFf9YSRYMnqMnKXizZ4RKB8dixPdGXgdtYmLYrY1xYY4HAV"
access_token <- "2717578724-rzBS0rZcNBg6xecEpFukQTFP4DVd4adeOgrhGHT"
access_token_secret <- "MeUkekEJ2Hu5f8uD9YECWBMhjJ9YdQ3mC9H7jbcbd00l0"
setup_twitter_oauth(api_key,api_secret,access_token,access_token_secret)

#Step1: Tweets Extraction

modi_tweets <- searchTwitter("$narendramodi", n = 100,lang='en')
namo_txt = sapply(modi_tweets, function(x) x$getText())
tweetsdf <- twListToDF(modi_tweets)
write.csv(tweetsdf, file='~/moditweets1k.csv',row.names = F)

trump_tweets <- searchTwitter("$realDonaldTrump", n = 100,lang='en')
dtrump_txt = sapply(trump_tweets, function(x) x$getText())
tweetsdf <- twListToDF(modi_tweets)
write.csv(tweetsdf, file='~/moditweets1k.csv',row.names = F)

#Step2: Data Cleaning

namo_txt = gsub('(RT|via)((?:\\b\\W*@\\w+)+)', '', namo_txt)
namo_txt = gsub('@\\w+', '', namo_txt)
namo_txt = gsub('[[:punct:]]', '', namo_txt)
namo_txt = gsub('[[:digit:]]', '', namo_txt)
namo_txt = gsub('http\\w+', '', namo_txt)
namo_txt = gsub('[ \t]{2,}', '', namo_txt)
namo_txt = gsub('^\\s+|\\s+$', '', namo_txt)



dtrump_txt = gsub('(RT|via)((?:\\b\\W*@\\w+)+)', '', dtrump_txt)
dtrump_txt = gsub('@\\w+', '', dtrump_txt)
dtrump_txt = gsub('[[:punct:]]', '', dtrump_txt)
dtrump_txt = gsub('[[:digit:]]', '', dtrump_txt)
dtrump_txt = gsub('http\\w+', '', dtrump_txt)
dtrump_txt = gsub('[ \t]{2,}', '', dtrump_txt)

dtrump_txt = gsub('^\\s+|\\s+$', '', dtrump_txt)

try.error = function(x)
{
  y = NA
  try_error = tryCatch(tolower(x), error=function(e) e)
  if (!inherits(try_error, 'error'))
    y = tolower(x)
  return(y)
}
namo_txt = sapply(namo_txt, try.error)
namo_txt = namo_txt[!is.na(namo_txt)]
names(namo_txt) = NULL

dtrump_txt = sapply(dtrump_txt, try.error)
dtrump_txt = dtrump_txt[!is.na(dtrump_txt)]
names(dtrump_txt) = NULL

#Step3: Emotion and Polarity Graphs

class_emo = classify_emotion(namo_txt, algorithm='bayes', prior=1.0)
namo_emotion = class_emo[,7]
namo_emotion[is.na(namo_emotion)] = 'unknown'


class_emo = classify_emotion(dtrump_txt, algorithm='bayes', prior=1.0)
dtrump_emotion = class_emo[,7]
dtrump_emotion[is.na(dtrump_emotion)] = 'unknown'


class_pol = classify_polarity(namo_txt, algorithm='bayes')
namo_polarity = class_pol[,4]
namo_df= data.frame(text=namo_txt, namo_emotion=namo_emotion,
                    namo_polarity=namo_polarity, stringsAsFactors=FALSE)

class_pol = classify_polarity(dtrump_txt, algorithm='bayes')
dtrump_polarity = class_pol[,4]
dtrump_df = data.frame(text=dtrump_txt, dtrump_emotion=dtrump_emotion,
                       dtrump_polarity=dtrump_polarity, stringsAsFactors=FALSE)

namo_df = within(namo_df,
                 namo_emotion <- factor(namo_emotion, levels=names(sort(table(namo_emotion), decreasing=TRUE))))

namo_df = data.frame(text = namo_df, namo_emotion = namo_emotion,
                     namo_polarity = namo_polarity, stringsAsFactors = FALSE)
namo_df = within(namo_df,
                 namo_emotion <- factor(namo_emotion, 
                                        levels = names(sort(table(namo_emotion), 
                                                            decreasing = TRUE))))
datatable(namo_df, class = "cell-border-stripe", 
          rownames = TRUE, 
          colnames = c("tweet", "Emotion", "Polarity"), 
          options = list(pageLength = 10))

dtrump_df = within(dtrump_df,
                   dtrump_emotion <- factor(dtrump_emotion, levels=names(sort(table(dtrump_emotion), decreasing=TRUE))))

dtrump_df = data.frame(text = dtrump_df, dtrump_emotion = dtrump_emotion,
                       dtrump_polarity = dtrump_polarity, stringsAsFactors = FALSE)
dtrump_df = within(dtrump_df,
                   dtrump_emotion <- factor(dtrump_emotion, 
                                            levels = names(sort(table(dtrump_emotion), 
                                                                decreasing = TRUE))))
datatable(dtrump_df, class = "cell-border-stripe", 
          rownames = TRUE, 
          colnames = c("tweet", "Emotion", "Polarity"), 
          options = list(pageLength = 10))

raw=c(namo_emotion,dtrump_emotion)
emoton_cat= c(namo_df,dtrump_df)
polaritytot= c(namo_polarity,dtrump_polarity)
namo_dataFrame= data.frame(raw,polaritytot, check.rows = FALSE)

levels(namo_emotion) = c(levels(namo_emotion),"None")
namo_emotion[is.na(namo_emotion)] = "None"

levels(dtrump_emotion) = c(levels(dtrump_emotion),"None")
dtrump_emotion[is.na(dtrump_emotion)] = "None"

library(stringr)


Emotions= c(rep("anger",2),rep("disgust",2),rep("fear",2),rep("joy",2),rep("sadness",2),rep("surprise",2))
Candidates= rep(c("Donald Trump","Narendra Modi"),6)
Values= c(sum(str_count(namo_emotion,"anger")),sum(str_count(dtrump_emotion,"anger")),sum(str_count(namo_emotion,"disgust")),
          sum(str_count(dtrump_emotion,"disgust")), sum(str_count(namo_emotion,"fear")),
          sum(str_count(dtrump_emotion,"fear")),
          sum(str_count(namo_emotion,"joy")),
          sum(str_count(dtrump_emotion,"joy")),
          sum(str_count(namo_emotion,"sadness")),
          sum(str_count(dtrump_emotion,"sadness")),
          sum(str_count(namo_emotion,"surprise")),
          sum(str_count(dtrump_emotion,"surprise"))
)
emotions_data=data.frame(Emotions,Candidates,Values)
ggplot(emotions_data, aes(fill=Candidates, y=Values, x=Emotions)) + 
  geom_bar(position="dodge", stat="identity")


Polarities= c (rep("positive",2), rep("negative",2), rep("nuetral",2))
Polarity_Candidates= rep(c("Narendra Modi","Donald Trump"),3)
Polarity_Values = c(sum(str_count(namo_polarity,"positive")), sum(str_count(dtrump_polarity,"positive")),
                    sum(str_count(namo_polarity,"negative")), sum(str_count(dtrump_polarity,"negative")),
                    sum(str_count(namo_polarity,"neutral")), sum(str_count(dtrump_polarity,"neutral")))

polarity_data= data.frame(Polarities,Polarity_Candidates,Polarity_Values)

ggplot(polarity_data, aes(fill=Polarity_Candidates, y=Polarity_Values, x=Polarities)) + 
  geom_bar(position="dodge", stat="identity")

plot1= ggplot(namo_df, aes(x=namo_emotion)) +
  geom_bar(aes(y=..count.., fill=namo_emotion)) +
  scale_fill_brewer(palette='Dark2') +
  labs(x='emotion categories', y='number of tweets') +
  ggtitle('Sentiment Analysis of Modi') +theme_minimal()

plot2= ggplot(dtrump_df, aes(x=dtrump_emotion)) +
  geom_bar(aes(y=..count.., fill=dtrump_emotion)) +
  scale_fill_brewer(palette='Dark2') +
  labs(x='emotion categories', y='number of tweets') +
  ggtitle('Sentiment Analysis of Trump') +theme_minimal()


grid.newpage()
grid.draw(rbind(ggplotGrob(plot1), ggplotGrob(plot2), size = "last"))


#ggplot for polarity
ggplot(namo_df, aes(x=polarity)) +
  geom_bar(aes(y=..count.., fill=polarity)) +
  scale_fill_brewer(palette='RdGy') +
  labs(x='polarity categories', y='number of tweets') +
  ggtitle('Sentiment Analysis of Tweets about Narendra Modi\n(classification by polarity)') +
  theme(plot.title = element_text(size=12, face='bold'))
emos = levels(factor(namo_df$emotion))
nemo = length(emos)
emo.docs = rep('', nemo)
for (i in 1:nemo)
{
  tmp = some_txt[emotion == emos[i]]
  emo.docs[i] = paste(tmp, collapse=' ')
}
emo.docs = removeWords(emo.docs, stopwords('english'))
emo.docs = removeWords(emo.docs, stopwords('german'))
emo.docs = removeWords(emo.docs, stopwords('french'))
corpus = Corpus(VectorSource(emo.docs))
tdm = TermDocumentMatrix(corpus)
tdm = as.matrix(tdm)
colnames(tdm) = emos

#Step4 : Word Cloud Generation 

comparison.cloud(tdm, colors = brewer.pal(nemo, 'Dark2'),
                 scale = c(3,.5), random.order = FALSE, title.size = 1.5)
emos = levels(factor(sent_df$emotion))
nemo = length(emos)
emo.docs = rep("", nemo)
for (i in 1:nemo)
{
  tmp = some_txt[emotion == emos[i]]
  emo.docs[i] = paste(tmp, collapse=" ")
}

comparison.cloud(tdm, colors = brewer.pal(nemo, "Dark2"),
                 scale = c(3,.5), random.order = FALSE, title.size = 1.5)

